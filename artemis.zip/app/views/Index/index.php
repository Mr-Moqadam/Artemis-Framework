<h1><?php
echo $this->post;
?>
	</h1>