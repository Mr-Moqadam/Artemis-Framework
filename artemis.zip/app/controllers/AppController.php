<?php 
/**
* app/controllers/AppController.php
**/

class AppController extends Controller
{
	
}