<?php 
/*
* Artemis Framework
* 
* Object Class
* @author : Saeed Moqadam Zade
**/
 
class Object
{

	function Object()
	{
 
	}
	

	function __destruct()
	{
		unset($this);	
	}
}